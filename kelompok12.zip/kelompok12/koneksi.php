<?php 
	
	$db = new PDO('mysql:host=localhost;dbname=web2', 'root', '');
	
 ?>